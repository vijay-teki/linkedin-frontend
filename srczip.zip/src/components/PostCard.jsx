import React from "react";

export default function PostCard({ p }) {
  return (
    <div className="bg-white p-4 rounded shadow mb-4">
      <div className="flex items-center gap-3 mb-2">
        <img src={p.author?.profileImage?.url || "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"} alt="avatar" className="w-10 h-10 rounded-full object-cover" />
        <div>
          <div className="font-semibold">{p.author?.name || "Unknown"}</div>
          <div className="text-xs text-gray-500">{new Date(p.createdAt).toLocaleString()}</div>
        </div>
      </div>
      <div className="mb-2">{p.text}</div>
      {p.media?.url && (
        p.media.type === "video" ? (
          <video src={p.media.url} controls className="w-full rounded" />
        ) : (
          <img src={p.media.url} alt="media" className="w-full rounded object-cover max-h-96" />
        )
      )}
    </div>
  );
}
