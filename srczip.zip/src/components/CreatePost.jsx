import React, { useState } from "react";
import API from "../api/axios";

export default function CreatePost({ onPosted }) {
  const [text, setText] = useState("");
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (!text.trim() && !file) return alert("Add text or media");
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append("text", text);
      if (file) fd.append("media", file);
      await API.post("/posts", fd);
      setText("");
      setFile(null);
      onPosted && onPosted();
    } catch (err) {
      alert(err.response?.data?.message || "Could not post");
    } finally { setLoading(false); }
  };

  return (
    <div className="bg-white p-4 rounded shadow">
      <form onSubmit={submit}>
        <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Share an update" className="w-full p-2 border rounded mb-2"></textarea>
        <div className="flex justify-between items-center">
          <input type="file" onChange={e => setFile(e.target.files[0])} />
          <button disabled={loading} className="bg-blue-600 text-white px-4 py-1 rounded">{loading ? "Posting..." : "Post"}</button>
        </div>
      </form>
    </div>
  );
}
