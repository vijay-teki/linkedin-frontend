import React, { useEffect, useState, useContext } from "react";
import Navbar from "../components/Navbar";
import API from "../api/axios";
import { UserContext } from "../context/UserContext";

export default function Feed() {
  const { user } = useContext(UserContext);
  const [posts, setPosts] = useState([]);
  const [text, setText] = useState("");
  const [file, setFile] = useState(null);

  useEffect(() => {
    const fetchPosts = async () => {
      const res = await API.get("/posts");
      setPosts(res.data.reverse());
    };
    fetchPosts();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData();
    fd.append("text", text);
    if (file) fd.append("media", file);
    await API.post("/posts", fd);
    setText("");
    setFile(null);
    const res = await API.get("/posts");
    setPosts(res.data.reverse());
  };

  return (
    <>
      <Navbar />
      <div className="pt-20 bg-gray-100 min-h-screen flex justify-center px-4">
        <div className="w-full max-w-2xl">
          {/* CREATE POST */}
          <div className="bg-white rounded-lg shadow p-4 mb-6">
            <div className="flex items-center gap-3 mb-3">
              <img
                src={
                  user?.profileImage?.url ||
                  "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
                }
                alt="avatar"
                className="w-12 h-12 rounded-full object-cover"
              />
              <input
                type="text"
                placeholder="Start a post"
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="flex-1 border rounded-full px-4 py-2 bg-gray-100 hover:bg-gray-200 cursor-pointer"
              />
            </div>

            {file && (
              <div className="mt-2 text-sm text-gray-600">Attached: {file.name}</div>
            )}

            <div className="flex justify-between items-center mt-3">
              <label className="flex items-center gap-2 cursor-pointer text-gray-600">
                <i className="fa-solid fa-image text-blue-600"></i>
                <span>Photo</span>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => setFile(e.target.files[0])}
                />
              </label>
              <button
                onClick={handleSubmit}
                className="bg-[#0A66C2] text-white px-5 py-1.5 rounded-full hover:bg-[#004182]"
              >
                Post
              </button>
            </div>
          </div>

          {/* POSTS */}
          {posts.map((p) => (
            <div
              key={p._id}
              className="bg-white rounded-lg shadow p-4 mb-4 hover:shadow-md transition"
            >
              <div className="flex items-center gap-3 mb-2">
                <img
                  src={
                    p.author?.profileImage?.url ||
                    "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
                  }
                  alt="user"
                  className="w-10 h-10 rounded-full"
                />
                <div>
                  <h4 className="font-semibold">{p.author?.name}</h4>
                  <p className="text-xs text-gray-500">{p.author?.email}</p>
                </div>
              </div>
              <p className="text-gray-800 mb-3">{p.text}</p>
              {p.media?.url && (
                <img
                  src={p.media.url}
                  alt="post"
                  className="w-full rounded-lg object-cover"
                />
              )}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
